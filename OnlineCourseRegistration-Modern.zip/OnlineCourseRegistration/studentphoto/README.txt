Placeholder for student photos
